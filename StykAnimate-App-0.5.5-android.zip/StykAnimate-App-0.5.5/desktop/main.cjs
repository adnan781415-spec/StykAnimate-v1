'use strict';

const { app, BrowserWindow, Menu, dialog, ipcMain, shell, session, clipboard, contentTracing } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const { mkdirSync, existsSync } = require('node:fs');
const { startBackend } = require('./backend.cjs');
const { RecoveryStore, atomicWrite } = require('./recovery.cjs');
const { FileStreams } = require('./file-streams.cjs');
const { SharedClipboard } = require('./shared-clipboard.cjs');
const { workspaceDirectory } = require('./workspace-instance.cjs');
const { spawn } = require('node:child_process');
const { WorkspacePreferences } = require('./preferences.cjs');
const { ProjectFiles } = require('./project-files.cjs');
const { FontService } = require('./font-service.cjs');
const { VideoExportService } = require('./video-export-service.cjs');
const { VfwExportService } = require('./vfw-export-service.cjs');
const { RecentFiles } = require('./recent-files.cjs');
const { LibraryStore } = require('./library-store.cjs');
const { TelemetryService } = require('./telemetry.cjs');
const { UpdateService, updateAvailability } = require('./updates.cjs');
const releaseInfo = require('./release-info.json');
const { RELEASES_URL, DONATE_URL } = require('./release-links.cjs');

const APP_ROOT = path.resolve(__dirname, '..');
const MAX_FILE_BYTES = 256 * 1024 * 1024;
const FILE_FILTERS = [
  { name: 'Animation and stick figures', extensions: ['styk', 'stykmov', 'stkz', 'piv', 'stk', 'json', 'nodes', 'nodemc', 'stknds', 'zip'] },
  { name: 'StykAnimate movieclip', extensions: ['stykmov'] },
  { name: 'StykAnimate figure', extensions: ['stkz'] },
  { name: 'Pivot animation', extensions: ['piv'] },
  { name: 'Pivot stick figure', extensions: ['stk'] },
  { name: 'StykAnimate project', extensions: ['styk', 'json'] },
];
let window;
let backend;
let fileStreams;
let videoExports;
let vfwExports;
let recentFiles;
let library;
let telemetry;
let telemetryReady;
let telemetryClosed = false;
let updates;
let startupShown = false;
let traceRunning = false;
let pendingProtocol = process.argv.find(value => /^stykanimate:\/\//i.test(value));
function handleProtocol(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'stykanimate:' || url.username || url.password || url.search || url.hash || url.port || !['', '/'].includes(url.pathname) || !['open', 'privacy'].includes(url.hostname)) return false;
    if (!window || window.webContents.isLoading()) { pendingProtocol = value; return true; }
    if (window.isMinimized()) window.restore(); window.show(); window.focus();
    if (url.hostname === 'privacy') sendAction('privacy');
    return true;
  } catch { return false; }
}
const projectFiles = new ProjectFiles();
let documentState = { name: 'Untitled', dirty: false };
let quitting = false;
let pendingFiles = process.argv.slice(app.isPackaged ? 1 : 2).filter((arg) => /\.(piv|stk|styk|stkz|stykmov|json|nodes|nodemc|stknds|zip)$/i.test(arg));

// WebGPU uses Chromium's normal driver allowlist. The opt-in switch is useful
// for Linux development on drivers Chromium has not yet qualified.
if (process.env.STYK_GPU_UNSAFE === '1') app.commandLine.appendSwitch('enable-unsafe-webgpu');

app.setName('StykAnimate');
const profileDirectory = process.env.STYK_USER_DATA_DIR || (!app.isPackaged ? path.join(APP_ROOT, '.desktop-data') : null);
if (profileDirectory) {
  mkdirSync(profileDirectory, { recursive: true });
  app.setPath('userData', profileDirectory);
  app.setPath('sessionData', profileDirectory);
  app.setPath('crashDumps', path.join(profileDirectory, 'crashes'));
}
const primaryInstance = app.requestSingleInstanceLock();
const instanceDirectory = primaryInstance ? app.getPath('userData') : workspaceDirectory(app.getPath('userData'));
if (!primaryInstance) {
  mkdirSync(instanceDirectory, {recursive: true});
  app.setPath('sessionData', instanceDirectory);
  app.setPath('crashDumps', path.join(instanceDirectory, 'crashes'));
}
if (!primaryInstance && pendingProtocol) app.quit();
else {
  app.on('second-instance', (_event, argv) => {
    // Each ordinary launch owns its project. Protocol links still target the
    // primary workspace without opening an extra editor.
    for (const value of argv.filter(arg => /^stykanimate:\/\//i.test(arg))) handleProtocol(value);
  });
  app.on('open-url', (event, url) => { event.preventDefault(); handleProtocol(url); });
  app.on('open-file', (event, file) => { event.preventDefault(); queueOpenFile(file); });
  app.whenReady().then(start).catch(async (error) => {
    dialog.showErrorBox('StykAnimate could not start', error.message);
    app.quit();
  });
}

function trusted(event) {
  const url = event.senderFrame?.url || '';
  if (!window || event.sender !== window.webContents || !backend || new URL(url).origin !== backend.origin) {
    throw new Error('This operation is restricted to the StykAnimate workspace.');
  }
}

function sendAction(action) {
  if (!window || window.isDestroyed()) return;
  window.webContents.send('styk:menu-action', action);
}

function windowState() {
  return { maximized: window?.isMaximized() || false, fullscreen: window?.isFullScreen() || false, focused: window?.isFocused() || false };
}

function nativeMenu() {
  // Editor shortcuts belong to the renderer's customizable, focus-aware dispatcher.
  // Native accelerators would intercept disabled/reassigned keys and text editing.
  const item = (label, action) => ({ label, click: () => sendAction(action) });
  const template = [
    ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
    { label: 'File', submenu: [
      item('New animation', 'new'),
      item('New window', 'new-window'),
      item('Open…', 'open'),
      { type: 'separator' },
      item('Save', 'save'),
      item('Save as…', 'save-as'),
      item('Save figure…', 'export-stkz'),
      item('Export…', 'export'),
      { type: 'separator' },
      process.platform === 'darwin' ? { role: 'close' } : { role: 'quit' },
    ] },
    { label: 'Edit', submenu: [
      item('Undo', 'undo'), item('Redo', 'redo'),
      { type: 'separator' },
      item('Cut', 'cut'), item('Copy', 'copy'), item('Paste', 'paste'),
      item('Duplicate', 'duplicate'), item('Delete', 'delete'),
      { type: 'separator' }, item('Select all', 'select-all'),
    ] },
    { label: 'Animation', submenu: [
      item('Play / pause', 'play'), item('Add frame', 'add-frame'),
      item('Previous frame', 'previous-frame'), item('Next frame', 'next-frame'),
      { type: 'separator' }, item('Onion skin', 'toggle-onion'),
    ] },
    { label: 'View', submenu: [
      item('Zoom in', 'zoom-in'), item('Zoom out', 'zoom-out'),
      item('Fit canvas', 'zoom-reset'), { type: 'separator' }, { role: 'togglefullscreen', accelerator: '' },
      ...(!app.isPackaged ? [{ role: 'toggleDevTools', accelerator: '' }] : []),
    ] },
    { label: 'Help', submenu: [item('Keyboard shortcuts', 'help'), item('Check for updates…', 'check-updates'), item('What’s new', 'release-notes'), item('Support development', 'donate'), item('About StykAnimate', 'about')] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

async function readImportFile(file) {
  const started = performance.now();
  const extension = path.extname(file).toLowerCase();
  if (!['.piv', '.stk', '.styk', '.stkz', '.stykmov', '.json', '.nodes', '.nodemc', '.stknds', '.zip'].includes(extension)) throw new Error('Choose a StykAnimate, Pivot or Stick Nodes file.');
  const limit = ['.styk', '.stkz', '.stykmov', '.json'].includes(extension) ? MAX_FILE_BYTES : 128 * 1024 * 1024;
  const stat = await fs.stat(file);
  if (!stat.isFile()) throw new Error('Choose an animation or stick figure file.');
  if (stat.size > limit) throw new Error(`This file exceeds the ${limit / 1024 / 1024} MB import limit.`);
  const bytes = await fs.readFile(file);
  if (bytes.length > limit) throw new Error('This file grew past the import limit while being read.');
  app.addRecentDocument(file);
  await rememberRecent(file);
  // The renderer transfers these compact source bytes to its import worker.
  // Expanded JSON is never parsed or transported through Electron main.
  return {
    bytes: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    filename: path.basename(file),
    nativePath: file,
    openToken: projectFiles.rememberOpen(path.resolve(file)),
    kind: extension === '.stykmov' ? 'stykmov' : extension === '.stkz' ? 'stkz' : extension === '.stk' ? 'stk' : extension === '.piv' ? 'piv' : 'styk',
    sourceBytes: bytes.length,
    timings: { native_read_ms: +(performance.now() - started).toFixed(3) },
  };
}

async function rememberRecent(file) {
  if (!recentFiles || !/\.(piv|stk|styk|stkz|stykmov|json|nodes|nodemc|stknds|zip)$/i.test(file)) return;
  // A damaged preferences directory must not turn a completed save into failure.
  try { await recentFiles.remember(path.resolve(file)); }
  catch (error) { console.warn('Recent files could not be updated:', error.message); }
}

async function queueOpenFile(file) {
  if (!window || !backend || window.webContents.isLoading()) { pendingFiles.push(file); return; }
  try { window.webContents.send('styk:file-opened', await readImportFile(file)); }
  catch (error) { dialog.showErrorBox('Unable to open file', error.message); }
}

function registerIpc() {
  ipcMain.handle('styk:update-state', event => { trusted(event); return updates.snapshot(); });
  ipcMain.handle('styk:update-check', event => { trusted(event); void updates.check(); return updates.snapshot(); });
  ipcMain.handle('styk:update-releases', event => { trusted(event); return shell.openExternal(RELEASES_URL); });
  ipcMain.handle('styk:donate', event => { trusted(event); return shell.openExternal(DONATE_URL); });
  ipcMain.handle('styk:release-info', (event, startup = false) => {
    trusted(event);
    if (startup && startupShown) return null;
    if (startup) startupShown = true;
    return { ...releaseInfo, version: app.getVersion() };
  });
  ipcMain.handle('styk:update-restart', event => {
    trusted(event);
    return updates.restart(async () => {
      const revision = documentState.revision;
      if (documentState.dirty) {
        const answer = await dialog.showMessageBox(window, {
          type: 'question', title: 'Restart to update', message: `Save changes to ${documentState.name}?`,
          detail: 'StykAnimate will close, install the downloaded update, and reopen.',
          buttons: ['Save and restart', 'Cancel', 'Discard and restart'], defaultId: 0, cancelId: 1,
        });
        if (answer.response === 0) { sendAction('save-and-update'); return false; }
        if (answer.response !== 2) return false;
      }
      if (telemetry && !telemetryClosed) { await telemetry.close().catch(() => {}); telemetryClosed = true; }
      if (documentState.revision !== revision) return false;
      quitting = true;
      return true;
    }, () => { quitting = false; });
  });
  const withTelemetry = handler => async (event, value) => { trusted(event); await telemetryReady; if (!telemetry) throw new Error('Privacy settings are unavailable. Please restart StykAnimate.'); return handler(value); };
  ipcMain.handle('styk:telemetry-state', withTelemetry(() => telemetry.getState()));
  ipcMain.handle('styk:telemetry-consent', withTelemetry(value => telemetry.setConsent(value)));
  ipcMain.handle('styk:telemetry-record', withTelemetry(value => telemetry.record(value)));
  ipcMain.handle('styk:telemetry-preview', withTelemetry(() => telemetry.preview()));
  ipcMain.handle('styk:telemetry-sync', withTelemetry(async () => { await telemetry.upload(); return telemetry.getState(); }));
  ipcMain.handle('styk:telemetry-delete', withTelemetry(() => telemetry.deleteData()));
  ipcMain.handle('styk:telemetry-feedback', withTelemetry(value => telemetry.feedback(value)));
  ipcMain.handle('styk:telemetry-export', withTelemetry(async () => {
    const result = await dialog.showSaveDialog(window, { title: 'Save optional telemetry report', defaultPath: 'StykAnimate-telemetry.json', filters: [{ name: 'JSON report', extensions: ['json'] }] });
    if (result.canceled || !result.filePath) return { saved: false };
    await fs.writeFile(result.filePath, JSON.stringify(telemetry.preview(), null, 2), 'utf8'); return { saved: true };
  }));
  ipcMain.handle('styk:service-page', withTelemetry(page => {
    const route = { home: '/', download: '/download/' }[page];
    if (!route) throw new Error('Unknown StykAnimate page.');
    if (!telemetry.siteUrl) throw new Error('The public website is not configured yet. Contact ale.ripreso@gmail.com.');
    return shell.openExternal(telemetry.siteUrl + route);
  }));
  ipcMain.handle('styk:performance-trace', async event => {
    trusted(event);
    if (traceRunning) throw new Error('A performance recording is already running.');
    traceRunning = true;
    let temporary;
    try {
      await contentTracing.startRecording({ included_categories: ['v8.execute', 'disabled-by-default-v8.cpu_profiler', 'devtools.timeline'], recording_mode: 'record-until-full', trace_buffer_size_in_kb: 16384 });
      await new Promise(resolve => setTimeout(resolve, !app.isPackaged && process.env.STYK_TRACE_TEST === '1' ? 2000 : 30000));
      temporary = await contentTracing.stopRecording();
      const result = await dialog.showSaveDialog(window, { title: 'Save local performance trace — review before sharing', defaultPath: 'StykAnimate-performance-trace.json', filters: [{ name: 'Chrome / Perfetto trace', extensions: ['json'] }] });
      if (result.canceled || !result.filePath) return { saved: false };
      await fs.copyFile(temporary, result.filePath); return { saved: true };
    } finally { traceRunning = false; if (temporary) await fs.unlink(temporary).catch(() => {}); }
  });
  for (const [channel, method] of [['list','list'], ['mkdir','createFolder'], ['thumbnail','thumbnail'], ['save-begin','beginSave'], ['write','write'], ['finish','finish'], ['cancel','cancel'], ['read-begin','beginRead'], ['read','read'], ['change','change']])
    ipcMain.handle(`styk:library-${channel}`, (event, ...args) => { trusted(event); return library[method](...args); });
  ipcMain.handle('styk:library-reveal', async (event, folder = '') => { trusted(event); const error = await shell.openPath(await library.folder(folder)); if (error) throw new Error(error); });
  ipcMain.handle('styk:library-trash', (event, relative) => { trusted(event); return library.trash(relative, target => shell.trashItem(target)); });
  ipcMain.handle('styk:library-thumbnail-cache', (event, options) => { trusted(event); return library.cacheThumbnail(options); });
  recentFiles = new RecentFiles({directory: app.getPath('userData'), limit: 20});
  ipcMain.handle('styk:recent-list', event => { trusted(event); return recentFiles.list(); });
  ipcMain.handle('styk:recent-open', async (event, id) => { trusted(event); return readImportFile(await recentFiles.resolve(id)); });
  ipcMain.handle('styk:recent-clear', event => { trusted(event); return recentFiles.clear(); });
  ipcMain.handle('styk:clipboard-text-read', event => {
    trusted(event); const text = clipboard.readText();
    if (text.length > 100) throw new Error('The clipboard does not contain a short segment value.');
    return text;
  });
  ipcMain.handle('styk:clipboard-text-write', (event, text) => {
    trusted(event);
    if (typeof text !== 'string' || text.length > 100) throw new Error('Segment clipboard text must contain at most 100 characters.');
    clipboard.writeText(text); return true;
  });
  const encoderRoot = app.isPackaged ? process.resourcesPath : path.join(APP_ROOT, 'build');
  videoExports = new VideoExportService({encoderPath: path.join(encoderRoot, 'video-encoder', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'), tempRoot: app.getPath('temp')});
  for (const [channel, method] of [
    ['video-capabilities', 'capabilities'], ['video-begin', 'begin'], ['video-frame-begin', 'beginFrame'], ['video-frame-chunk', 'writeFrameChunk'],
    ['video-frame-end', 'endFrame'], ['video-finish', 'finish'], ['video-read', 'read'], ['video-cancel', 'cancel'],
  ]) ipcMain.handle(`styk:${channel}`, (event, ...args) => { trusted(event); return videoExports[method](...args); });
  const vfwRoot = app.isPackaged ? path.join(process.resourcesPath, 'vfw') : path.join(APP_ROOT, 'native', 'bin');
  vfwExports = new VfwExportService({helperPaths: {x86: path.join(vfwRoot, 'x86', 'styk-vfw.exe'), x64: path.join(vfwRoot, 'x64', 'styk-vfw.exe')}, tempRoot: app.getPath('temp')});
  for (const [channel, method] of [
    ['vfw-capabilities', 'capabilities'], ['vfw-begin', 'begin'], ['vfw-frame-begin', 'beginFrame'], ['vfw-frame-chunk', 'writeFrameChunk'],
    ['vfw-frame-end', 'endFrame'], ['vfw-finish', 'finish'], ['vfw-read', 'read'], ['vfw-cancel', 'cancel'],
  ]) ipcMain.handle(`styk:${channel}`, (event, ...args) => { trusted(event); return vfwExports[method](...args); });
  ipcMain.handle('styk:vfw-configure', async (event, options) => {
    trusted(event); const owner = window;
    const handle = owner.getNativeWindowHandle();
    const hwnd = (handle.length >= 8 ? handle.readBigUInt64LE() : BigInt(handle.readUInt32LE())).toString();
    try { return await vfwExports.configure(options, hwnd); }
    finally { if (!owner.isDestroyed()) { owner.setEnabled(true); owner.focus(); } }
  });
  const recovery = new RecoveryStore(instanceDirectory);
  const sharedClipboard = new SharedClipboard(clipboard);
  for (const [channel, method] of [['write-begin', 'beginWrite'], ['write', 'write'], ['finish', 'finish'], ['read-begin', 'beginRead'], ['read', 'read'], ['cancel', 'cancel']])
    ipcMain.handle(`styk:shared-clipboard-${channel}`, (event, ...args) => { trusted(event); return sharedClipboard[method](...args); });
  app.on('will-quit', () => sharedClipboard.dispose());
  ipcMain.handle('styk:new-window', event => {
    trusted(event);
    return new Promise((resolve, reject) => {
      const child = spawn(process.execPath, app.isPackaged ? [] : [APP_ROOT], {detached: true, stdio: 'ignore', windowsHide: true, env: process.env});
      child.once('error', reject);
      child.once('spawn', () => { child.unref(); resolve(true); });
    });
  });
  const preferences = new WorkspacePreferences(app.getPath('userData'));
  const editorSettings = new WorkspacePreferences(app.getPath('userData'), { filename: 'editor-settings.json' });
  const fonts = new FontService();
  ipcMain.handle('styk:fonts-list', event => { trusted(event); return fonts.listFonts(); });
  ipcMain.handle('styk:fonts-read', async (event, id) => {
    trusted(event); const bytes = await fonts.readFont(id);
    return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  });
  ipcMain.handle('styk:workspace-preferences-get', (event) => { trusted(event); return preferences.get(); });
  ipcMain.handle('styk:workspace-preferences-set', (event, value) => { trusted(event); return preferences.set(value); });
  ipcMain.handle('styk:editor-settings-get', (event) => { trusted(event); return editorSettings.get(); });
  ipcMain.handle('styk:editor-settings-set', (event, value) => { trusted(event); return editorSettings.set(value); });
  fileStreams = new FileStreams();
  const clipboardFile = path.join(app.getPath('userData'), 'frame-clipboard.styk');
  let clipboardWriteToken = null, clipboardControl = Promise.resolve();
  ipcMain.handle('styk:clipboard-write-begin', (event, options) => {
    trusted(event); fileStreams.validateSize(options?.size);
    if (!options.size) throw new Error('The frame clipboard is empty.');
    const pending = clipboardControl.then(async () => {
      if (clipboardWriteToken) await fileStreams.cancel(clipboardWriteToken);
      const transfer = await fileStreams.beginWrite({destination: clipboardFile, size: options.size});
      clipboardWriteToken = transfer.token; return transfer;
    });
    clipboardControl = pending.catch(() => {}); return pending;
  });
  ipcMain.handle('styk:clipboard-read-begin', async event => {
    trusted(event); const transfer = await fileStreams.beginRead(clipboardFile);
    return transfer ? {...transfer, name: 'Copied keyframes'} : null;
  });
  const projectTransfers = new Map();
  let projectRequestPending = false;
  ipcMain.handle('styk:document-activate', async (event, options) => {
    trusted(event);
    const document = projectFiles.activate(options || {});
    const stale = [...projectTransfers.keys()];
    projectTransfers.clear();
    await Promise.all(stale.map((token) => fileStreams.cancel(token)));
    return document;
  });
  ipcMain.handle('styk:project-write-begin', async (event, options) => {
    trusted(event);
    fileStreams.validateSize(options?.size);
    const document = projectFiles.requireCurrent(options?.documentToken);
    for (const token of projectTransfers.keys()) if (!fileStreams.jobs.has(token)) projectTransfers.delete(token);
    if (projectRequestPending || projectTransfers.size) throw new Error('A project save is already in progress.');
    projectRequestPending = true;
    try {
      let destination = document.filename;
      if (options.saveAs || !destination) {
        const result = await dialog.showSaveDialog(window, {
          title: options.saveAs ? 'Save animation as' : 'Save animation',
          defaultPath: destination || path.basename(String(options.defaultPath || 'Untitled.styk')),
          filters: [{ name: 'StykAnimate project', extensions: ['styk'] }],
          properties: ['createDirectory', 'showOverwriteConfirmation'],
        });
        if (result.canceled || !result.filePath) return null;
        destination = projectFiles.validateDestination(result.filePath);
      }
      projectFiles.requireCurrent(document.documentToken);
      const transfer = await fileStreams.beginWrite({ destination, size: options.size, onCommit: async () => {
        // A document switch invalidates old capabilities, including pending dialogs.
        if (projectFiles.current?.documentToken === document.documentToken) projectFiles.commit(document.documentToken, destination);
        app.addRecentDocument(destination);
        await rememberRecent(destination);
      } });
      try { projectFiles.requireCurrent(document.documentToken); }
      catch (error) { await fileStreams.cancel(transfer.token); throw error; }
      projectTransfers.set(transfer.token, document.documentToken);
      return { ...transfer, filename: path.basename(destination), documentToken: document.documentToken };
    } finally { projectRequestPending = false; }
  });
  let recoveryWriteToken = null;
  let recoveryControl = Promise.resolve();
  function controlRecovery(operation) {
    const result = recoveryControl.then(operation);
    recoveryControl = result.catch(() => {});
    return result;
  }
  ipcMain.handle('styk:file-write-begin', async (event, options) => {
    trusted(event);
    fileStreams.validateSize(options?.size);
    const filters = Array.isArray(options.filters) ? options.filters.slice(0, 8).map((filter) => ({
      name: String(filter.name || 'File').slice(0, 80),
      extensions: Array.isArray(filter.extensions) ? filter.extensions.filter((ext) => /^[a-z0-9*]{1,12}$/i.test(ext)) : [],
    })).filter((filter) => filter.extensions.length) : [{ name: 'StykAnimate project', extensions: ['styk'] }];
    const result = await dialog.showSaveDialog(window, {
      title: 'Save animation', defaultPath: path.basename(String(options.defaultPath || 'Untitled.styk')), filters,
      properties: ['createDirectory', 'showOverwriteConfirmation'],
    });
    if (result.canceled || !result.filePath) return null;
    return fileStreams.beginWrite({ destination: result.filePath, size: options.size, onCommit: async () => {
      app.addRecentDocument(result.filePath);
      await rememberRecent(result.filePath);
    } });
  });
  ipcMain.handle('styk:recovery-write-begin', async (event, options) => {
    trusted(event);
    fileStreams.validateSize(options?.size);
    if (!options.size) throw new Error('Recovery data is empty.');
    return controlRecovery(async () => {
      if (recoveryWriteToken) await fileStreams.cancel(recoveryWriteToken);
      const result = await fileStreams.beginWrite({ destination: recovery.file, size: options.size, onCommit: () => recovery.updateMetadata(options.name) });
      recoveryWriteToken = result.token;
      return result;
    });
  });
  ipcMain.handle('styk:file-write-chunk', (event, token, bytes) => { trusted(event); return fileStreams.write(token, bytes); });
  ipcMain.handle('styk:file-write-finish', async (event, token) => {
    trusted(event);
    const documentToken = projectTransfers.get(token);
    if (documentToken) projectFiles.requireCurrent(documentToken);
    try {
      const result = await fileStreams.finish(token);
      if (token === recoveryWriteToken) recoveryWriteToken = null;
      return documentToken ? { ...result, documentToken, filename: path.basename(result.path) } : result;
    } finally { if (!fileStreams.jobs.has(token)) projectTransfers.delete(token); }
  });
  ipcMain.handle('styk:file-write-cancel', async (event, token) => {
    trusted(event);
    const result = await fileStreams.cancel(token);
    projectTransfers.delete(token);
    if (token === recoveryWriteToken) recoveryWriteToken = null;
    return result;
  });
  ipcMain.handle('styk:recovery-info', (event) => { trusted(event); return recovery.info(); });
  ipcMain.handle('styk:recovery-read-begin', async (event) => {
    trusted(event);
    const info = await recovery.info();
    if (!info) return null;
    const transfer = await fileStreams.beginRead(recovery.file);
    return transfer ? { ...info, ...transfer } : null;
  });
  ipcMain.handle('styk:file-read-chunk', (event, token) => { trusted(event); return fileStreams.read(token); });
  ipcMain.handle('styk:file-read-close', (event, token) => { trusted(event); return fileStreams.closeRead(token); });
  ipcMain.handle('styk:recovery-save', (event, options) => {
    trusted(event);
    return controlRecovery(async () => {
      if (recoveryWriteToken) { await fileStreams.cancel(recoveryWriteToken); recoveryWriteToken = null; }
      return recovery.save(options);
    });
  });
  ipcMain.handle('styk:recovery-get', (event) => { trusted(event); return recovery.get(); });
  ipcMain.handle('styk:recovery-delete', async (event) => {
    trusted(event);
    return controlRecovery(async () => {
      if (recoveryWriteToken) { await fileStreams.cancel(recoveryWriteToken); recoveryWriteToken = null; }
      return recovery.delete();
    });
  });
  ipcMain.handle('styk:open-file', async (event) => {
    trusted(event);
    const result = await dialog.showOpenDialog(window, { title: 'Open animation or stick figure', properties: ['openFile'], filters: FILE_FILTERS });
    return result.canceled ? null : readImportFile(result.filePaths[0]);
  });
  ipcMain.handle('styk:save-file', async (event, options) => {
    trusted(event);
    if (!options || typeof options !== 'object') throw new Error('Save options are required.');
    let data;
    if (typeof options.data === 'string') {
      if (!['base64', 'utf8', undefined].includes(options.encoding)) throw new Error('Unsupported file encoding.');
      data = Buffer.from(options.data, options.encoding || 'utf8');
    } else if (options.data instanceof Uint8Array || Array.isArray(options.data)) data = Buffer.from(options.data);
    else throw new Error('The file must contain text or bytes.');
    if (data.byteLength > MAX_FILE_BYTES) throw new Error('This export exceeds the 256 MB limit.');
    const filters = Array.isArray(options.filters) ? options.filters.slice(0, 8).map((filter) => ({
      name: String(filter.name || 'File').slice(0, 80),
      extensions: Array.isArray(filter.extensions) ? filter.extensions.filter((ext) => /^[a-z0-9*]{1,12}$/i.test(ext)) : [],
    })).filter((filter) => filter.extensions.length) : [{ name: 'StykAnimate project', extensions: ['styk'] }];
    const result = await dialog.showSaveDialog(window, {
      title: 'Save animation',
      defaultPath: path.basename(String(options.defaultPath || 'Untitled.styk')),
      filters,
      properties: ['createDirectory', 'showOverwriteConfirmation'],
    });
    if (result.canceled || !result.filePath) return null;
    // Only the path selected by the native dialog is writable through this API.
    await atomicWrite(result.filePath, data);
    app.addRecentDocument(result.filePath);
    await rememberRecent(result.filePath);
    return { saved: true, path: result.filePath };
  });
  ipcMain.handle('styk:window', (event, action) => {
    trusted(event);
    if (action === 'minimize') window.minimize();
    else if (action === 'maximize') window.isMaximized() ? window.unmaximize() : window.maximize();
    else if (action === 'close') window.close();
    else throw new Error('Unknown window action.');
    return windowState();
  });
  ipcMain.handle('styk:window-state', (event) => { trusted(event); return windowState(); });
  ipcMain.handle('styk:document-state', (event, state) => {
    trusted(event);
    documentState = { name: String(state?.name || 'Untitled').slice(0, 180), dirty: Boolean(state?.dirty), revision: String(state?.revision || '').slice(0, 160) };
    window.setTitle(`${documentState.dirty ? '• ' : ''}${documentState.name} — StykAnimate`);
    window.setDocumentEdited(documentState.dirty);
  });
}

async function createWindow() {
  window = new BrowserWindow({
    width: 1560, height: 1000, minWidth: 1000, minHeight: 680,
    backgroundColor: '#191a1d', show: false,
    title: 'StykAnimate',
    icon: path.join(__dirname, 'assets', 'stykanimate.png'),
    frame: process.platform === 'darwin',
    ...(process.platform === 'darwin' ? { titleBarStyle: 'hidden', trafficLightPosition: { x: 14, y: 16 } } : {}),
    autoHideMenuBar: process.platform !== 'darwin',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true, nodeIntegration: false, sandbox: true,
      webSecurity: true, allowRunningInsecureContent: false,
      backgroundThrottling: true, spellcheck: false,
    },
  });
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\/(?:github\.com|pivotanimator\.net)\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  window.webContents.on('will-navigate', (event, url) => {
    if (new URL(url).origin !== backend.origin) event.preventDefault();
  });
  window.webContents.on('will-attach-webview', (event) => event.preventDefault());
  window.webContents.on('render-process-gone', (_event, details) => { if (details.reason !== 'clean-exit') telemetry?.error('RendererCrash', 'renderer', 'renderer_crashes'); });
  window.on('unresponsive', () => telemetry?.error('RendererHang', 'renderer', 'renderer_hangs'));
  for (const event of ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen', 'focus', 'blur']) {
    window.on(event, () => window.webContents.send('styk:window-state', windowState()));
  }
  window.on('close', async (event) => {
    if (!quitting && documentState.dirty) {
      event.preventDefault();
      const answer = await dialog.showMessageBox(window, {
        type: 'question', title: 'Unsaved animation', message: `Save changes to ${documentState.name}?`,
        detail: 'Your animation has changes that have not been saved.',
        buttons: ['Save', 'Cancel', 'Discard'], defaultId: 0, cancelId: 1,
      });
      if (answer.response === 0) sendAction('save-and-close');
      else if (answer.response === 2) { documentState.dirty = false; window.close(); }
    }
  });
  window.on('closed', () => { window = null; });
  window.once('ready-to-show', () => window.show());
  await window.loadURL(backend.origin);
  if (pendingProtocol) { const value = pendingProtocol; pendingProtocol = null; handleProtocol(value); }
  if (process.env.STYK_DEVTOOLS === '1') window.webContents.openDevTools({ mode: 'detach' });
  const files = pendingFiles.splice(0);
  for (const file of files) await queueOpenFile(file);
}

async function start() {
  const unavailable = updateAvailability({ packaged: app.isPackaged, platform: process.platform,
    portable: Boolean(process.env.PORTABLE_EXECUTABLE_DIR), installed: existsSync(path.join(path.dirname(process.execPath), 'Uninstall StykAnimate.exe')) });
  const updater = unavailable ? null : require('electron-updater').autoUpdater;
  if (updater) updater.installDirectory = path.dirname(process.execPath);
  updates = new UpdateService({ updater,
    currentVersion: app.getVersion(), unavailable,
    onState: value => { if (value.status === 'error') quitting = false; if (window && !window.isDestroyed()) window.webContents.send('styk:update-state-changed', value); },
  });
  if (app.isPackaged) app.setAsDefaultProtocolClient('stykanimate');
  telemetryReady = new TelemetryService({ directory: app.getPath('userData'), schemaPath: path.join(app.isPackaged ? path.join(process.resourcesPath, 'web') : APP_ROOT, 'src', 'telemetry-schema.mjs'), version: app.getVersion(), development: !app.isPackaged,
    onState: value => { if (window && !window.isDestroyed()) window.webContents.send('styk:telemetry-state-changed', value); },
  }).init().then(service => { telemetry = service; return service; }).catch(() => { /* Optional reporting cannot prevent startup. */ });
  const memoryTimer = setInterval(() => {
    if (telemetry?.state.consent.diagnostics && window?.isFocused()) {
      const metrics = app.getAppMetrics();
      telemetry.sampleMemory(metrics.reduce((sum, item) => sum + (item.memory?.workingSetSize || 0), 0) / 1024);
      telemetry.record({ epoch: telemetry.epoch, data: { gauges: { process_cpu_percent: metrics.reduce((sum, item) => sum + (item.cpu?.percentCPUUsage || 0), 0) } } });
    }
  }, 60000); memoryTimer.unref();
  library = new LibraryStore(process.env.STYK_LIBRARY_DIR || path.join(app.getPath('documents'), 'StykAnimate', 'library'));
  // A temporarily unavailable Documents volume should not prevent animation work.
  await library.init().catch(error => console.warn('Library initialization:', error.message));
  backend = await startBackend({
    appRoot: APP_ROOT, resourcesPath: process.resourcesPath, packaged: app.isPackaged,
    log: (message) => { if (process.env.STYK_DEBUG === '1') process.stderr.write(message); },
    onError: (message) => { telemetry?.error('BackendError', 'backend', 'backend_errors'); if (window && !window.isDestroyed()) window.webContents.send('styk:backend-error', message); },
  });
  session.defaultSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  session.defaultSession.setPermissionCheckHandler(() => false);
  nativeMenu();
  registerIpc();
  await createWindow();
  updates.start();
  app.on('activate', () => { if (!window) createWindow(); });
}

app.on('before-quit', (event) => {
  if (window && documentState.dirty && !quitting) { event.preventDefault(); window.close(); }
  else {
    quitting = true;
    if (telemetry && !telemetryClosed) { event.preventDefault(); telemetryClosed = true; void telemetry.close().catch(() => {}).finally(() => app.quit()); }
  }
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('will-quit', () => updates?.dispose());
app.on('will-quit', () => { backend?.stop(); library?.dispose().catch(() => {}); fileStreams?.dispose().catch(() => {}); videoExports?.dispose().catch(() => {}); vfwExports?.dispose().catch(() => {}); });
process.on('exit', () => backend?.stop());
